from django.apps import AppConfig


class AsambleasConfig(AppConfig):
    name = 'asambleas'