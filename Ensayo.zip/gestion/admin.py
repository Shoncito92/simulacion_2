from django.contrib import admin

# Register your models here.
from .models import Genero, EstadoCivil, Perfil

admin.site.register(Genero)
admin.site.register(EstadoCivil)


@admin.register(Perfil)
class PerfilAdmin(admin.ModelAdmin):
    """Administration object for usuario models.
    Defines:
     - fields to be displayed in list view (list_display)
     - orders fields in detail view (fields),
       grouping the date fields horizontally
     - adds inline addition of books in author view (inlines)
    """
    list_display = ('rut', 'display_genero')
    fields = ['rut', 'resumen', ('fecha_creacion', 'fecha_modificacion')]
    

