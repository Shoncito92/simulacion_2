# Ensayo de proyecto "Simulacion_2"
Practica para prueba de certificacion.
Awakelab - Python - 153-1
Jhonn Bruna.
